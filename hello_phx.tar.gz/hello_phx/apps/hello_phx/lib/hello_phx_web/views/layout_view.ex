defmodule HelloPhxWeb.LayoutView do
  use HelloPhxWeb, :view
end
