defmodule HelloPhxWeb.PageView do
  use HelloPhxWeb, :view
end
