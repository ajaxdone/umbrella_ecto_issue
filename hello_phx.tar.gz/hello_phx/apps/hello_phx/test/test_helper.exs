ExUnit.start()
Ecto.Adapters.SQL.Sandbox.mode(HelloPhx.Repo, :manual)
