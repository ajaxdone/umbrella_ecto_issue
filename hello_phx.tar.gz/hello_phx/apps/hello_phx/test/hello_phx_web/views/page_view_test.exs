defmodule HelloPhxWeb.PageViewTest do
  use HelloPhxWeb.ConnCase, async: true
end
