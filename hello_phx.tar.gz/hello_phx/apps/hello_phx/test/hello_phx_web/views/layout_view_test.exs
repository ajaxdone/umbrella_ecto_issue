defmodule HelloPhxWeb.LayoutViewTest do
  use HelloPhxWeb.ConnCase, async: true
end
